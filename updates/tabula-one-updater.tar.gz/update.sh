#!/usr/bin/env bash
# Runs on the centre's Linux host. Node is taken from its verified installed image.
set -Eeuo pipefail
umask 077
fail() { printf '%s\n' "$1" >&2; return 1; }
installation=""; local_release=""; local_payload=""; frozen_work=""; web_job=""; expected_revision=""; command=check
for argument in "$@"; do
  case "$argument" in
    --installation=*) installation=${argument#*=} ;;
    --release=*) local_release=${argument#*=} ;;
    --payload=*) local_payload=${argument#*=} ;;
    --internal-work=*) frozen_work=${argument#*=} ;;
    --web-job=*) web_job=${argument#*=} ;;
    --expected-revision=*) expected_revision=${argument#*=} ;;
    check|install|rollback) command=$argument ;;
    help|--help)
      printf '%s\n' 'Проверка: bash update.sh --installation=/папка/Tabula check' \
        'Установка: bash update.sh --installation=/папка/Tabula install' \
        'Откат последней попытки: bash update.sh --installation=/папка/Tabula rollback' \
        'Без сети: добавьте --release=/путь/latest.json --payload=/путь/пакет.json.gz'
      exit 0 ;;
    *) fail 'Неизвестный параметр обновлятора. Используйте help.' ;;
  esac
done
[[ -n "$installation" ]] || fail 'Укажите --installation с существующей папкой комплекта.'
BUNDLE=$(cd -- "$installation" && pwd -P)
[[ -z "$web_job" || "$web_job" =~ ^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$ ]] || fail 'Некорректная задача обновления.'
[[ -z "$expected_revision" || "$expected_revision" =~ ^20[0-9]{2}\.[0-9]{2}\.[0-9]{2}\.[0-9]{1,4}$ ]] || fail 'Некорректная ожидаемая версия.'
web_status() {
  [[ -n "$web_job" ]] || return 0
  local phase=$1 current=null available=null ready=false temporary spool="$BUNDLE/.tabula-web-update"
  [[ -d "$spool" && ! -L "$spool" ]] || fail 'Не найдена папка службы обновлений.'
  if [[ "${CURRENT_REVISION:-}" =~ ^20[0-9]{2}\.[0-9]{2}\.[0-9]{2}\.[0-9]{1,4}$ ]]; then current="\"$CURRENT_REVISION\""; fi
  if [[ "${NEW_REVISION:-}" =~ ^20[0-9]{2}\.[0-9]{2}\.[0-9]{2}\.[0-9]{1,4}$ ]]; then available="\"$NEW_REVISION\""; fi
  [[ "${UPDATE_AVAILABLE:-0}" != 1 ]] || ready=true
  temporary=$(mktemp "$spool/status.XXXXXXXX")
  printf '{"jobId":"%s","phase":"%s","currentRevision":%s,"availableRevision":%s,"updateAvailable":%s}\n' "$web_job" "$phase" "$current" "$available" "$ready" > "$temporary"
  chmod 0644 "$temporary"; mv -T -- "$temporary" "$spool/status.json"
}
[[ -f "$BUNDLE/BUNDLE-MANIFEST.json" && -f "$BUNDLE/IMAGES.tsv" && -f "$BUNDLE/tabula" ]] || fail 'Не найдена существующая установка Tabula One.'
for binary in docker sha256sum awk df cp mktemp flock cmp; do command -v "$binary" >/dev/null || fail "Не найдена команда: $binary"; done
[[ "$(uname -s)" == Linux && "$(uname -m)" == x86_64 ]] || fail 'Обновлятор предназначен для Linux x86_64.'
[[ "$(docker info --format '{{.OSType}}')" == linux ]] || fail 'Нужен работающий локальный Docker для Linux.'
[[ ! -L "$BUNDLE/.tabula-updates" ]] || fail 'Папка обновлений не должна быть символической ссылкой.'
mkdir -p -- "$BUNDLE/.tabula-updates"
if [[ -z "$frozen_work" ]]; then
  if [[ -n "$local_release" ]]; then local_release=$(cd -- "$(dirname -- "$local_release")" && printf '%s/%s' "$(pwd -P)" "$(basename -- "$local_release")"); fi
  if [[ -n "$local_payload" ]]; then local_payload=$(cd -- "$(dirname -- "$local_payload")" && printf '%s/%s' "$(pwd -P)" "$(basename -- "$local_payload")"); fi
  exec 9>"$BUNDLE/.tabula-updates/update.lock"
  flock -n 9 || fail 'Уже выполняется другое обновление этой установки.'
  if [[ "$command" == rollback ]]; then
    [[ -f "$BUNDLE/.tabula-updates/LAST" ]] || fail 'Нет сохранённой попытки для отката.'
    IFS=$'\t' read -r transaction phase < "$BUNDLE/.tabula-updates/LAST"
    [[ "$transaction" =~ ^update\.[a-zA-Z0-9._-]+$ ]] || fail 'Некорректная запись восстановления.'
    case "$phase" in complete|stopping|stopped|applying|verifying|ready-to-open|rollback-failed) ;; *) fail 'Последняя попытка не требует отката.' ;; esac
    WORK="$BUNDLE/.tabula-updates/$transaction"
    [[ -f "$WORK/tools/update.sh" ]] || fail 'Не найдена сохранённая копия обновлятора.'
  else
    if [[ -f "$BUNDLE/.tabula-updates/LAST" ]]; then
      IFS=$'\t' read -r previous phase < "$BUNDLE/.tabula-updates/LAST"
      case "$phase" in stopping|stopped|applying|verifying|ready-to-open|rollback-failed)
        fail 'Предыдущее обновление не завершено. Сначала выполните rollback.' ;;
      esac
    fi
    (cd -- "$BUNDLE" && sha256sum --check --strict CONTROL-SHA256SUMS >/dev/null) || fail 'Контрольные файлы установки изменены. Сохраните их перед обновлением.'
    WORK=$(mktemp -d "$BUNDLE/.tabula-updates/update.XXXXXXXXXX")
    printf '%s\n' "${WORK##*/}" > "$WORK/transaction-id"
    mkdir -- "$WORK/tools"
    TOOL_SOURCE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
    for file in update.sh update-core.mjs package.mjs update-public-key.pem; do cp -- "$TOOL_SOURCE/$file" "$WORK/tools/$file"; done
  fi
  exec bash "$WORK/tools/update.sh" "--installation=$BUNDLE" "--internal-work=$WORK" "$command" \
    ${local_release:+"--release=$local_release"} ${local_payload:+"--payload=$local_payload"} \
    ${web_job:+"--web-job=$web_job"} ${expected_revision:+"--expected-revision=$expected_revision"}
fi
WORK=$(cd -- "$frozen_work" && pwd -P)
[[ "$WORK" == "$BUNDLE"/.tabula-updates/update.* && "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)" == "$WORK/tools" ]] || fail 'Некорректная папка восстановления.'
[[ -e /proc/$$/fd/9 ]] || fail 'Не получена блокировка обновления.'
flock -n 9 || fail 'Обновление уже выполняется.'
cd -- "$BUNDLE"
maintenance=0; rollback_needed=0; services_stopped=0; committed=0
prepared_refs=()
manifest_table=IMAGES.tsv
if [[ "$command" == rollback ]]; then manifest_table="$WORK/backup/files/IMAGES.tsv"; fi
[[ -f "$manifest_table" ]] || fail 'Отсутствует исходная таблица образов.'
declare -A refs ids configs
while IFS=$'\t' read -r role reference expected config; do
  [[ "$role" =~ ^(app|public-edge|postgres|storage|livekit)$ && "$reference" =~ ^tabula-one-beta/[a-z-]+:[a-zA-Z0-9._-]+$ && "$expected" =~ ^sha256:[a-f0-9]{64}$ && "$config" =~ ^sha256:[a-f0-9]{64}$ ]] || fail 'Некорректная таблица образов.'
  [[ -z "${refs[$role]:-}" ]] || fail 'Повторный образ в таблице.'
  actual=$(docker image inspect --format '{{.Id}}' "$reference")
  [[ "$actual" == "$expected" || "$actual" == "$config" ]] || fail "Исходный образ изменён: $role"
  refs[$role]=$reference; ids[$role]=$expected; configs[$role]=$config
done < "$manifest_table"
[[ ${#refs[@]} == 5 ]] || fail 'Не хватает образов установки.'
APP_IMAGE=${refs[app]}
helper() {
  local action=$1; shift
  docker run --rm --pull never --network none --read-only --cap-drop ALL --security-opt no-new-privileges \
    --user "$(id -u):$(id -g)" --mount "type=bind,source=$WORK/tools,target=/tools,readonly" \
    --mount "type=bind,source=$BUNDLE,target=/bundle" --mount "type=bind,source=$WORK,target=/work" \
    --entrypoint node "$APP_IMAGE" /tools/update-core.mjs "$action" /bundle /work "$@"
}
download() {
  docker run --rm --pull never --read-only --cap-drop ALL --security-opt no-new-privileges \
    --user "$(id -u):$(id -g)" --mount "type=bind,source=$WORK/tools,target=/tools,readonly" \
    --mount "type=bind,source=$WORK,target=/work" --entrypoint node "$APP_IMAGE" \
    /tools/update-core.mjs "$1" /unused /work
}
compose() {
  local files=(-f deploy/server/compose.yaml -f deploy/server/compose.public.yaml -f deploy/server/compose.distribution.yaml)
  if (( maintenance )); then files+=(-f "$WORK/maintenance.compose.json"); fi
  docker compose --env-file deploy/server/.env "${files[@]}" "$@"
}
read_env() {
  local file=$1 key value
  while IFS=$'\t' read -r key value; do
    case "$key" in APP_REF|EDGE_REF|BASE_APP|BASE_EDGE|NEW_REVISION|CURRENT_REVISION|PAYLOAD_URL|PAYLOAD_BYTES|UPDATE_AVAILABLE|SITE_DNS|HTTPS_PORT|SITE_BIND|REHEARSAL) printf -v "$key" '%s' "$value" ;; *) fail 'Некорректный план обновления.' ;; esac
  done < "$file"
}
runtime_program=$(cat <<'JS'
import{Pool}from"pg";import{RoomServiceClient}from"livekit-server-sdk";import{readFile}from"node:fs/promises";import{createHash}from"node:crypto";
const e=process.env,p=new Pool({connectionString:e.LESSON_CANVAS_DATABASE_URL});try{
const counts=(await p.query("SELECT (SELECT count(*) FROM lesson_sessions WHERE status=$1)::int AS lessons,(SELECT count(*) FROM lesson_recordings WHERE status IN ($2,$3,$4))::int AS recordings,(SELECT count(*) FROM pgmigrations)::int AS migrations,pg_database_size(current_database()) AS database_bytes",["active","waiting","recording","processing"])).rows[0];
const rooms=await new RoomServiceClient(e.LESSON_CANVAS_LIVEKIT_INTERNAL_URL,e.LESSON_CANVAS_LIVEKIT_API_KEY,e.LESSON_CANVAS_LIVEKIT_API_SECRET,{requestTimeout:5}).listRooms();
const permit=(await p.query("SELECT md5(coalesce(string_agg(row_to_json(t)::text,chr(10) ORDER BY row_to_json(t)::text COLLATE \"C\"),'')) hash FROM installation_beta_permits t")).rows[0].hash;
console.log(JSON.stringify({...counts,databaseBytes:Number(counts.database_bytes),participants:rooms.reduce((n,r)=>n+r.numParticipants,0),installationId:e.LESSON_CANVAS_INSTALLATION_ID,betaRequired:e.LESSON_CANVAS_BETA_REQUIRED==="1",configHash:createHash("sha256").update(await readFile("/run/lesson-canvas/api.env")).digest("hex"),permitHash:permit}));
}catch{console.error("Не удалось проверить состояние базы и уроков. Исходная версия сохранена.");process.exitCode=1;}finally{await p.end();}
JS
)
runtime() { compose run --rm --no-deps -T api node --env-file=/run/lesson-canvas/api.env --input-type=module -e "$runtime_program" > "$WORK/$1"; }
infrastructure() {
  local service container volume
  for service in postgres storage livekit; do
    container=$(compose ps -q "$service"); [[ -n "$container" ]] || fail 'Сначала запустите базу, хранилище и видеосервис существующей установки.'
    printf '%s\t' "$service"; docker inspect --format '{{.Id}} {{.Image}}' "$container"
    docker inspect --format '{{range .Mounts}}{{json .}}{{println}}{{end}}' "$container" | LC_ALL=C sort
  done
  while IFS= read -r volume; do
    [[ -n "$volume" ]] || continue
    [[ "$(docker volume inspect --format '{{index .Labels "uz.tabulaone.installation"}}' "$volume")" == "$installation_id" ]] || fail 'Найден том другой установки.'
    docker volume inspect --format '{{.Name}} {{.Mountpoint}}' "$volume"
  done < <(docker volume ls --filter "label=com.docker.compose.project=$project" --format '{{.Name}}' | sort)
}
start_api() { compose up --detach --wait --wait-timeout 180 --no-build --pull never --no-deps --force-recreate api; }
start_worker() { compose up --detach --wait --wait-timeout 90 --no-build --pull never --no-deps --force-recreate cleanup; }
start_edge() { compose up --detach --wait --wait-timeout 90 --no-build --pull never --no-deps --force-recreate edge; }
probe() {
  local api
  api=$(compose ps -q api); [[ -n "$api" ]] || fail 'Приложение не запущено.'
  if [[ "$REHEARSAL" == true ]]; then compose exec -T edge cat /data/caddy/pki/authorities/local/root.crt > "$WORK/rehearsal-ca.pem"; fi
  docker run --rm --pull never --network "container:$api" --read-only --cap-drop ALL --security-opt no-new-privileges \
    --user "$(id -u):$(id -g)" --mount "type=bind,source=$WORK/tools,target=/tools,readonly" \
    --mount "type=bind,source=$WORK,target=/work" --entrypoint node "$APP_IMAGE" /tools/update-core.mjs probe /unused /work "$@"
}
rollback() {
  maintenance=0
  helper restore-check || return 1
  compose stop edge api cleanup || return 1
  helper restore || return 1
  start_api || return 1
  start_worker || return 1
  start_edge || return 1
  probe old || return 1
  infrastructure > "$WORK/infrastructure-after-rollback" || return 1
  cmp "$WORK/infrastructure-before" "$WORK/infrastructure-after-rollback" || return 1
  helper phase rolled-back || return 1
  printf '%s\n' 'Предыдущая версия восстановлена. Данные базы не откатывались.'
}
on_failure() {
  local code=$?; (( code != 0 )) || code=1
  local cleanup_allowed=0
  trap - ERR HUP INT TERM
  if (( rollback_needed && !committed )); then
    printf '%s\n' 'Обновление не завершено. Восстанавливаем предыдущую версию.' >&2
    if (( !services_stopped )); then
      maintenance=0
      if start_edge; then helper phase aborted || true; cleanup_allowed=1; else helper phase rollback-failed || true; fi
    elif rollback; then cleanup_allowed=1; else
      helper phase rollback-failed || true
      printf 'Требуется восстановление: bash %q --installation=%q rollback\n' "$WORK/tools/update.sh" "$BUNDLE" >&2
    fi
  elif (( committed )); then
    printf '%s\n' 'Новая версия работает, но не удалось записать итог. Сохраните папку последнего обновления.' >&2
  else
    cleanup_allowed=1
  fi
  if (( cleanup_allowed )); then
    for reference in "${prepared_refs[@]}"; do
      actual=$(docker image inspect --format '{{.Id}}' "$reference" 2>/dev/null) || continue
      [[ "$(docker image inspect --format '{{index .Config.Labels "uz.tabulaone.transaction"}}' "$reference")" == "${WORK##*/}" ]] || continue
      users=$(docker ps -aq --filter "ancestor=$actual") || continue
      [[ -z "$users" ]] || continue
      docker image rm "$reference" >/dev/null 2>&1 || true
    done
  fi
  exit "$code"
}
trap on_failure ERR HUP INT TERM
project=$(sed -n 's/^LC_PROJECT=//p' deploy/server/.env)
installation_id=$(sed -n 's/^LC_INSTALLATION_ID=//p' deploy/server/.env)
[[ "$project" =~ ^[a-z][a-z0-9-]{2,40}$ && "$installation_id" =~ ^[a-f0-9-]{36}$ ]] || fail 'Некорректный ID или имя проекта.'
if [[ "$command" == rollback ]]; then
  read_env "$WORK/plan.env"
  runtime runtime-rollback.json; helper gate runtime-rollback.json
  rollback
  exit 0
fi
web_status checking
helper inspect
if [[ -n "$local_release" ]]; then cp -- "$local_release" "$WORK/release.json"; else download download-feed; fi
helper release
read_env "$WORK/download.env"
[[ -z "$expected_revision" || "$expected_revision" == "$NEW_REVISION" ]] || fail 'Доступная версия изменилась. Проверьте обновления ещё раз.'
if [[ "$command" == check || "$UPDATE_AVAILABLE" == 0 ]]; then
  if [[ "$UPDATE_AVAILABLE" == 1 ]]; then web_status available; else web_status current; fi
  exit 0
fi
runtime runtime-initial.json; helper gate runtime-initial.json
web_status downloading
available=$(df -PB1 "$BUNDLE" | awk 'NR==2 {print $4}')
[[ "$available" =~ ^[0-9]+$ ]] && (( available > 2 * 1024 * 1024 * 1024 + PAYLOAD_BYTES * 6 )) || fail 'Для подготовки обновления нужно не меньше 2 ГБ свободного места плюс место для резервной копии базы.'
if [[ -n "$local_payload" ]]; then cp -- "$local_payload" "$WORK/payload.json.gz"; else download download-payload; fi
helper prepare
read_env "$WORK/plan.env"
[[ "$APP_REF" =~ ^tabula-one-beta/update-app:[a-zA-Z0-9._-]+$ && "$EDGE_REF" =~ ^tabula-one-beta/update-edge:[a-zA-Z0-9._-]+$ ]] || fail 'Некорректные новые образы.'
for reference in "$APP_REF" "$EDGE_REF"; do
  if docker image inspect "$reference" >/dev/null 2>&1; then fail 'Образ этой версии уже существует после прежней попытки. Проверьте журнал; существующие образы не перезаписываются.'; fi
done
runtime runtime-before.json; helper gate runtime-before.json space
infrastructure > "$WORK/infrastructure-before"
compose config --format json > "$WORK/compose-before.json"
docker run --rm --pull never --network none --entrypoint sh "$BASE_EDGE" -c 'sha256sum /srv/web/index.html' | awk '{print $1}' > "$WORK/old-web-index.sha"
cat > "$WORK/source/Update.Dockerfile" <<'DOCKERFILE'
ARG BASE_APP
ARG BASE_EDGE
FROM ${BASE_APP} AS app
USER root
WORKDIR /app/apps/api
COPY apps/api/dist /tmp/api-dist
COPY apps/api/migrations /tmp/api-migrations
COPY packages/shared/dist /tmp/shared-dist
RUN node --input-type=module -e 'import fs from "node:fs";import path from "node:path";import{createRequire}from"node:module";const require=createRequire(import.meta.url);const shared=path.dirname(require.resolve("@lesson-canvas/shared"));const allow=p=>{const s=fs.statSync(p);fs.chmodSync(p,s.isDirectory()?0o755:0o644);if(s.isDirectory())for(const f of fs.readdirSync(p))allow(path.join(p,f));};for(const[target,source]of[["/app/apps/api/dist","/tmp/api-dist"],["/app/apps/api/migrations","/tmp/api-migrations"],[shared,"/tmp/shared-dist"]]){fs.rmSync(target,{recursive:true,force:true});fs.cpSync(source,target,{recursive:true});allow(target);fs.rmSync(source,{recursive:true});}'
USER node
FROM ${BASE_EDGE} AS public-edge
RUN rm -rf /srv/web
COPY apps/web/dist /srv/web
DOCKERFILE
printf '**\n!apps/\n!apps/api/\n!apps/api/dist/\n!apps/api/dist/**\n!apps/api/migrations/\n!apps/api/migrations/**\n!apps/web/\n!apps/web/dist/\n!apps/web/dist/**\n!packages/\n!packages/shared/\n!packages/shared/dist/\n!packages/shared/dist/**\n' > "$WORK/source/Update.Dockerfile.dockerignore"
for role in app public-edge; do
  target=$APP_REF; [[ "$role" == app ]] || target=$EDGE_REF
  prepared_refs+=("$target")
  docker build --pull=false --network=none --build-arg "BASE_APP=$BASE_APP" --build-arg "BASE_EDGE=$BASE_EDGE" \
    --label "uz.tabulaone.update=$NEW_REVISION" --label "uz.tabulaone.installation=$installation_id" \
    --label "uz.tabulaone.transaction=${WORK##*/}" \
    --target "$role" -t "$target" -f "$WORK/source/Update.Dockerfile" "$WORK/source"
done
docker image inspect "$APP_REF" "$EDGE_REF" > "$WORK/new-images.json"
helper stage
helper backup
printf '{"services":{"api":{"environment":{"LESSON_CANVAS_UPDATE_MAINTENANCE":"1"}}}}\n' > "$WORK/maintenance.compose.json"
helper unchanged
runtime runtime-preflight.json; helper gate runtime-preflight.json same
helper phase prepared
helper phase stopping
web_status installing
rollback_needed=1
compose stop edge
runtime runtime-last-check.json; helper gate runtime-last-check.json same
services_stopped=1
compose stop api cleanup
compose exec -T postgres sh -c 'exec pg_dump -U "${POSTGRES_USER:-postgres}" -d "${POSTGRES_DB:-lesson_canvas}" --format=custom' > "$WORK/backup/database.dump"
[[ -s "$WORK/backup/database.dump" ]] || fail 'Резервная копия базы пуста.'
compose exec -T postgres pg_restore --list < "$WORK/backup/database.dump" > "$WORK/backup/database-contents.txt"
helper phase stopped
helper apply
compose config --format json > "$WORK/compose-after.json"
helper compose
helper phase applying
maintenance=1
start_api
runtime runtime-new.json; helper gate runtime-new.json same
start_edge
helper phase verifying
probe
infrastructure > "$WORK/infrastructure-after"
cmp "$WORK/infrastructure-before" "$WORK/infrastructure-after"
compose stop edge api
maintenance=0
start_api
runtime runtime-final.json; helper gate runtime-final.json same
start_worker
helper phase ready-to-open
start_edge
probe
committed=1
rollback_needed=0
helper phase complete
CURRENT_REVISION=$NEW_REVISION; UPDATE_AVAILABLE=0
web_status complete
trap - ERR HUP INT TERM
printf 'Обновление %s установлено. ID, настройки, разрешение и данные сохранены.\nРезервная копия: %s/backup\n' "$NEW_REVISION" "$WORK"
