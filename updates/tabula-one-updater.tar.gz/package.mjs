import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { access, chmod, lstat, mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const roles = ["app", "public-edge", "postgres", "storage", "livekit"];
const sourceFiles = [
  "deploy/server/compose.yaml",
  "deploy/server/compose.public.yaml",
  "deploy/server/compose.account-mail.yaml",
  "deploy/server/configure.mjs",
  "deploy/server/preflight.mjs",
  "deploy/server/preflight.sh",
  "deploy/server/distribution/update.sh",
  "deploy/server/distribution/update-core.mjs",
  "deploy/server/distribution/update-public-key.pem",
  "deploy/server/distribution/web-update-agent.sh",
  "deploy/server/distribution/package.mjs",
];
const documentFiles = [
  "README.md",
  "INSTALL.md",
  "BETA-ACCESS.md",
  "THIRD-PARTY.md",
  "SOURCE-CHANGES.json",
  "UPDATE.md",
];
const appServices = ["setup", "api", "cleanup", "master", "teacher"];
const persistentVolumes = [
  "pdf_pages",
  "centre_branding",
  "recording_work",
  "postgres_data",
  "storage_meta",
  "storage_data",
  "api_config",
  "worker_config",
  "caddy_data",
  "caddy_config",
];

export function validateImages(images) {
  if (!Array.isArray(images) || images.length !== roles.length)
    throw new Error("Five image roles are required");
  for (const role of roles) {
    const matches = images.filter((image) => image.role === role);
    if (matches.length !== 1) throw new Error(`Missing or duplicate image role: ${role}`);
    const image = matches[0];
    if (
      !/^tabula-one-beta\/[a-z-]+:[a-zA-Z0-9._-]+$/.test(image.reference) ||
      !/^sha256:[a-f0-9]{64}$/.test(image.id) ||
      image.os !== "linux" ||
      image.architecture !== "amd64"
    )
      throw new Error(`Invalid release image: ${role}`);
  }
  if (new Set(images.map((image) => image.reference)).size !== images.length)
    throw new Error("Image references must be unique");
  return images;
}

export function distributionOverlay(images) {
  validateImages(images);
  const refs = Object.fromEntries(images.map((image) => [image.role, image.reference]));
  const lines = [
    "# Generated from inspected images; no build or registry pull at installation.",
    "services:",
  ];
  for (const name of [...appServices, "edge", "postgres", "storage", "livekit"]) {
    const role = appServices.includes(name) ? "app" : name === "edge" ? "public-edge" : name;
    lines.push(`  ${name}:`, `    image: ${refs[role]}`, "    pull_policy: never");
    if (appServices.includes(name) || name === "edge") lines.push("    build: !reset null");
    lines.push(
      "    labels:",
      "      uz.tabulaone.installation: ${LC_INSTALLATION_ID:?Run configuration first}",
    );
    if (name === "api")
      lines.push(
        "    environment:",
        "      LESSON_CANVAS_INSTALLATION_ID: ${LC_INSTALLATION_ID:?Run configuration first}",
        '      LESSON_CANVAS_BETA_REQUIRED: "1"',
        "      LESSON_CANVAS_WEB_UPDATE_DIR: /run/tabula-update",
        "    volumes:",
        "      - ../../.tabula-web-update:/run/tabula-update",
      );
  }
  for (const [section, names] of [
    ["volumes", persistentVolumes],
    ["networks", ["private", "outbound"]],
  ]) {
    lines.push(`${section}:`);
    for (const name of names)
      lines.push(
        `  ${name}:`,
        "    labels:",
        "      uz.tabulaone.installation: ${LC_INSTALLATION_ID:?Run configuration first}",
      );
  }
  return lines.join("\n") + "\n";
}

export async function hashFile(file) {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return hash.digest("hex");
}

// Older/classic stores expose the config ID; newer stores may expose a manifest ID.
export function configDigestsFromArchiveManifest(manifest, references) {
  if (!Array.isArray(manifest)) throw new Error("Invalid Docker-save manifest");
  return new Map(
    references.map((reference) => {
      const entries = manifest.filter((entry) => entry.RepoTags?.includes(reference));
      if (entries.length !== 1)
        throw new Error(`Missing or duplicate archived image: ${reference}`);
      const match = /^(?:blobs\/sha256\/([a-f0-9]{64})|([a-f0-9]{64})\.json)$/.exec(
        entries[0].Config,
      );
      if (!match) throw new Error("Unexpected Docker image configuration path");
      return [reference, `sha256:${match[1] ?? match[2]}`];
    }),
  );
}

async function write(directory, name, bytes, mode = 0o644) {
  const file = join(directory, name);
  await mkdir(dirname(file), { recursive: true });
  await writeFile(file, bytes, { flag: "wx", mode });
  await chmod(file, mode);
}

async function regularFiles(directory, prefix = "") {
  const found = [];
  for (const entry of await readdir(join(directory, prefix), { withFileTypes: true })) {
    const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isSymbolicLink()) throw new Error("Symlinks are not permitted in release notices");
    if (entry.isDirectory()) found.push(...(await regularFiles(directory, relative)));
    else if (entry.isFile()) found.push(relative);
    else throw new Error("Unexpected release file type");
  }
  return found.sort();
}

export async function createDistribution({
  root,
  target,
  revision,
  images,
  noticesDirectory,
  archiveImages,
  sourceCommit = "52c3540512cf8450cc9306c59c0b84ad40f8e1f9",
  sourceRelease = "v0.2.20-beta.20261024",
}) {
  validateImages(images);
  if (
    !/^[a-f0-9]{40}$/.test(sourceCommit) ||
    !/^v[0-9]+\.[0-9]+\.[0-9]+(?:-[a-zA-Z0-9.]+)?$/.test(sourceRelease)
  )
    throw new Error("Invalid package source identity");
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}$/.test(revision))
    throw new Error("Invalid release revision");
  root = resolve(root);
  target = resolve(target);
  if (target === root || root.startsWith(target + "/"))
    throw new Error("Use a separate output directory");
  await access(target).then(
    () => {
      throw new Error("Output already exists; existing installations are never overwritten");
    },
    () => {},
  );
  const noticeFiles = await regularFiles(resolve(noticesDirectory));
  if (!noticeFiles.length) throw new Error("Image notices are required");
  await mkdir(target, { recursive: true });
  const textInput = async (file) => (await readFile(file, "utf8")).replace(/\r\n/g, "\n");
  for (const file of sourceFiles) await write(target, file, await textInput(join(root, file)));
  for (const file of documentFiles)
    await write(target, file, await textInput(join(root, "docs/server-beta", file)));
  for (const file of noticeFiles)
    await write(target, `notices/${file}`, await readFile(join(noticesDirectory, file)));
  const configDigests = await archiveImages(
    join(target, "images.tar"),
    images.map((image) => image.reference),
  );
  images = images.map((image) => {
    const configDigest = configDigests?.get(image.reference);
    if (!/^sha256:[a-f0-9]{64}$/.test(configDigest))
      throw new Error(`Missing portable image identity: ${image.role}`);
    return { ...image, configDigest };
  });
  const wrapper = (await textInput(join(root, "deploy/server/distribution/tabula.sh"))).replace(
    "@@APP_IMAGE@@",
    images.find((image) => image.role === "app").reference,
  );
  if (wrapper.includes("@@APP_IMAGE@@")) throw new Error("Unresolved wrapper image");
  await write(target, "tabula", wrapper, 0o755);
  await write(target, "deploy/server/compose.distribution.yaml", distributionOverlay(images));
  await write(
    target,
    "IMAGES.tsv",
    images
      .map((image) => `${image.role}\t${image.reference}\t${image.id}\t${image.configDigest}`)
      .join("\n") + "\n",
  );
  const files = [];
  for (const file of await regularFiles(target)) {
    const info = await lstat(join(target, file));
    files.push({ path: file, bytes: info.size, sha256: await hashFile(join(target, file)) });
  }
  const manifest = {
    schemaVersion: 1,
    revision,
    platform: "linux/amd64",
    installable: true,
    readyForExternalBeta: false,
    betaAccess: "signed-permit-v1",
    externalReleaseGates: [
      "component-source-distribution-review",
      "target-server-dns-https-rtc-acceptance",
    ],
    sourceChangesSha256: await hashFile(join(target, "SOURCE-CHANGES.json")),
    sourceCommit,
    sourceRelease,
    githubActions: false,
    imageTransport: "included-docker-save-archive",
    images,
    files,
    mutablePaths: ["deploy/server/.env", "deploy/server/.secrets"],
    externalDnsRtcAcceptance: "required-on-target-server",
  };
  await write(target, "BUNDLE-MANIFEST.json", JSON.stringify(manifest, null, 2) + "\n");
  const manifestEntry = {
    path: "BUNDLE-MANIFEST.json",
    sha256: await hashFile(join(target, "BUNDLE-MANIFEST.json")),
  };
  const controlEntries = [...files.filter((file) => file.path !== "images.tar"), manifestEntry];
  await write(
    target,
    "CONTROL-SHA256SUMS",
    controlEntries.map((file) => `${file.sha256}  ${file.path}`).join("\n") + "\n",
  );
  const sums = [
    ...files,
    manifestEntry,
    { path: "CONTROL-SHA256SUMS", sha256: await hashFile(join(target, "CONTROL-SHA256SUMS")) },
  ];
  await write(
    target,
    "SHA256SUMS",
    sums.map((file) => `${file.sha256}  ${file.path}`).join("\n") + "\n",
  );
  return manifest;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const options = {};
    for (const arg of process.argv.slice(2)) {
      const match = /^--(target|revision|images|notices|source-commit|source-release)=(.+)$/.exec(
        arg,
      );
      if (!match)
        throw new Error(
          "Use --target=DIR --revision=VERSION --images=JSON --notices=DIR [--source-commit=SHA --source-release=VERSION]",
        );
      options[match[1]] = match[2];
    }
    if (
      ![4, 6].includes(Object.keys(options).length) ||
      !["target", "revision", "images", "notices"].every((key) => options[key])
    )
      throw new Error("Four package options and an optional source identity pair are required");
    const docker = process.env.LESSON_CANVAS_DOCKER_COMMAND ?? "docker";
    const images = JSON.parse(await readFile(resolve(options.images), "utf8"));
    validateImages(images);
    for (const image of images) {
      const actual = JSON.parse(
        execFileSync(docker, ["image", "inspect", image.reference], {
          encoding: "utf8",
          windowsHide: true,
        }),
      )[0];
      if (
        actual.Id !== image.id ||
        actual.Os !== image.os ||
        actual.Architecture !== image.architecture
      )
        throw new Error(`Loaded image differs from manifest: ${image.role}`);
    }
    const manifest = await createDistribution({
      root: fileURLToPath(new URL("../../../", import.meta.url)),
      target: options.target,
      revision: options.revision,
      images,
      noticesDirectory: resolve(options.notices),
      ...(options["source-commit"]
        ? { sourceCommit: options["source-commit"], sourceRelease: options["source-release"] }
        : {}),
      archiveImages(file, references) {
        execFileSync(docker, ["image", "save", "--output", file, ...references], {
          stdio: "inherit",
          windowsHide: true,
        });
        const manifest = JSON.parse(
          execFileSync("tar", ["-xOf", file, "manifest.json"], {
            encoding: "utf8",
            windowsHide: true,
          }),
        );
        return configDigestsFromArchiveManifest(manifest, references);
      },
    });
    console.log(
      JSON.stringify({
        status: "DISTRIBUTION_CREATED",
        revision: manifest.revision,
        files: manifest.files.length,
        imageCount: manifest.images.length,
        readyForExternalBeta: false,
      }),
    );
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
