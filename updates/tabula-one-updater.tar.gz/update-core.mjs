import { createHash, verify, sign, randomUUID } from "node:crypto";
import { gzipSync, gunzipSync } from "node:zlib";
import {
  readFile,
  writeFile,
  mkdir,
  lstat,
  readdir,
  rename,
  unlink,
  statfs,
} from "node:fs/promises";
import { resolve, dirname, join, posix } from "node:path";
import { fileURLToPath } from "node:url";
import { isIP } from "node:net";
import { request as httpsRequest } from "node:https";
import { distributionOverlay, validateImages, hashFile, roles } from "./package.mjs";

export const updateProtocol = 1;
export const updateFeed =
  "https://raw.githubusercontent.com/alexvectorgsai/tabula-one-server/main/updates/latest.json";
export const maximumPayloadBytes = 64 * 1024 * 1024;
export const maximumUnpackedBytes = 256 * 1024 * 1024;
const digestPattern = /^[a-f0-9]{64}$/;
const revisionPattern = /^20\d{2}\.\d{2}\.\d{2}\.\d{1,4}$/;
const keyFile = new URL("update-public-key.pem", import.meta.url);
export const bundleUpdateFiles = [
  "tabula",
  "README.md",
  "INSTALL.md",
  "UPDATE.md",
  "SOURCE-CHANGES.json",
  "deploy/server/distribution/update.sh",
  "deploy/server/distribution/update-core.mjs",
  "deploy/server/distribution/package.mjs",
  "deploy/server/distribution/update-public-key.pem",
];
const fail = (message) => {
  throw new Error(message);
};
export const sha256 = (value) => createHash("sha256").update(value).digest("hex");
export function canonical(value, depth = 0) {
  if (depth > 24) fail("Слишком сложное описание обновления.");
  if (value === null || ["string", "boolean"].includes(typeof value)) return JSON.stringify(value);
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map((v) => canonical(v, depth + 1)).join(",") + "]";
  if (typeof value !== "object" || !value) fail("Некорректное описание обновления.");
  return (
    "{" +
    Object.keys(value)
      .sort()
      .map((k) => JSON.stringify(k) + ":" + canonical(value[k], depth + 1))
      .join(",") +
    "}"
  );
}
export function compareRevision(a, b) {
  if (![a, b].every((v) => typeof v === "string" && revisionPattern.test(v)))
    fail("Некорректная версия комплекта.");
  const aa = a.split(".").map(Number),
    bb = b.split(".").map(Number);
  for (let i = 0; i < aa.length; i++) if (aa[i] !== bb[i]) return Math.sign(aa[i] - bb[i]);
  return 0;
}
export function safePath(path) {
  if (
    typeof path !== "string" ||
    !/^[A-Za-z0-9_./-]+$/.test(path) ||
    path.length > 240 ||
    path.startsWith("/") ||
    path.split("/").some((p) => !p || p === "." || p === "..") ||
    posix.normalize(path) !== path
  )
    fail("Недопустимый путь в обновлении.");
  return path;
}
export function releaseUrl(value) {
  if (
    typeof value !== "string" ||
    !/^https:\/\/github\.com\/alexvectorgsai\/tabula-one-server\/releases\/download\/server-beta-20\d{2}\.\d{2}\.\d{2}\.\d{1,4}\/tabula-one-update-[a-zA-Z0-9._-]+\.json\.gz$/.test(
      value,
    )
  )
    fail("Недопустимый адрес пакета обновления.");
  return value;
}
export function validateRelease(m) {
  if (
    !m ||
    m.schemaVersion !== 1 ||
    m.product !== "tabula-one-server" ||
    m.protocol !== updateProtocol ||
    m.platform !== "linux/amd64" ||
    !revisionPattern.test(m.revision) ||
    !/^[a-f0-9]{40}$/.test(m.sourceCommit ?? "") ||
    !/^v\d+\.\d+\.\d+-[a-zA-Z0-9.]+$/.test(m.sourceRelease ?? "") ||
    typeof m.notes !== "string" ||
    m.notes.length > 10000 ||
    !Number.isFinite(Date.parse(m.publishedAt))
  )
    fail("Этот формат обновления не поддерживается. Скачайте свежий обновлятор.");
  if (
    !m.compatibility ||
    !digestPattern.test(m.compatibility.fingerprint ?? "") ||
    !digestPattern.test(m.compatibility.migrations ?? "") ||
    m.compatibility.rollbackSafe !== true ||
    !Array.isArray(m.compatibility.legacyBases) ||
    m.compatibility.legacyBases.length > 30 ||
    !Number.isInteger(m.compatibility.migrationCount) ||
    m.compatibility.migrationCount < 1
  )
    fail("В обновлении отсутствует подтверждение совместимости.");
  for (const base of m.compatibility.legacyBases) {
    if (
      !revisionPattern.test(base.revision ?? "") ||
      !/^[a-f0-9]{40}$/.test(base.sourceCommit ?? "") ||
      !roles.every((role) => /^sha256:[a-f0-9]{64}$/.test(base.images?.[role] ?? ""))
    )
      fail("Некорректная совместимость прежнего комплекта.");
  }
  const p = m.payload;
  if (
    !p ||
    !digestPattern.test(p.sha256 ?? "") ||
    !Number.isSafeInteger(p.bytes) ||
    p.bytes < 1 ||
    p.bytes > maximumPayloadBytes ||
    !Number.isSafeInteger(p.unpackedBytes) ||
    p.unpackedBytes < 1 ||
    p.unpackedBytes > maximumUnpackedBytes ||
    !Number.isInteger(p.fileCount) ||
    p.fileCount < 1 ||
    p.fileCount > 10000
  )
    fail("Недопустимый размер обновления.");
  releaseUrl(p.url);
  if (
    p.url !==
    `https://github.com/alexvectorgsai/tabula-one-server/releases/download/server-beta-${m.revision}/tabula-one-update-${m.revision}.json.gz`
  )
    fail("Адрес пакета не соответствует версии обновления.");
  return m;
}
export function signRelease(manifest, privateKey) {
  validateRelease(manifest);
  return {
    schemaVersion: 1,
    manifest,
    signature: sign(null, Buffer.from(canonical(manifest)), privateKey).toString("base64"),
  };
}
export function verifyRelease(bytes, publicKey) {
  if (bytes.length > 128 * 1024) fail("Описание обновления слишком велико.");
  let envelope;
  try {
    envelope = JSON.parse(bytes);
  } catch {
    fail("Не удалось прочитать описание обновления.");
  }
  if (
    !envelope ||
    envelope.schemaVersion !== 1 ||
    typeof envelope.signature !== "string" ||
    !/^[A-Za-z0-9+/]{86}==$/.test(envelope.signature)
  )
    fail("Отсутствует подпись обновления.");
  if (
    !verify(
      null,
      Buffer.from(canonical(envelope.manifest)),
      publicKey,
      Buffer.from(envelope.signature, "base64"),
    )
  )
    fail("Подпись обновления не подтверждена. Установка отменена.");
  return validateRelease(envelope.manifest);
}
const applicationPath = (p) =>
  !p.split("/").some((part) => part.startsWith(".")) &&
  !/\.(?:env|pem|key)$/i.test(p) &&
  (/^(?:apps\/api\/dist\/|apps\/web\/dist\/|packages\/shared\/dist\/)/.test(p) ||
    /^apps\/api\/migrations\/[A-Za-z0-9_-]+\.js$/.test(p));
export function encodePayload(entries) {
  const json = Buffer.from(
    JSON.stringify({
      schemaVersion: 1,
      files: entries.map(({ path, bytes }) => ({
        path,
        bytes: bytes.length,
        sha256: sha256(bytes),
        contentBase64: bytes.toString("base64"),
      })),
    }),
  );
  return {
    compressed: gzipSync(json, { level: 9 }),
    unpackedBytes: json.length,
    fileCount: entries.length,
  };
}
export function decodePayload(bytes, manifest) {
  if (bytes.length !== manifest.payload.bytes || sha256(bytes) !== manifest.payload.sha256)
    fail("Контрольная сумма пакета не совпала.");
  const json = gunzipSync(bytes, {
    maxOutputLength: Math.min(maximumUnpackedBytes, manifest.payload.unpackedBytes),
  });
  if (json.length !== manifest.payload.unpackedBytes)
    fail("Размер содержимого обновления не совпал.");
  const payload = JSON.parse(json);
  if (
    payload.schemaVersion !== 1 ||
    !Array.isArray(payload.files) ||
    payload.files.length !== manifest.payload.fileCount
  )
    fail("Некорректный состав обновления.");
  const seen = new Set();
  const files = payload.files.map((entry) => {
    const p = safePath(entry.path);
    if (
      seen.has(p) ||
      !(applicationPath(p) || (p.startsWith("bundle/") && bundleUpdateFiles.includes(p.slice(7))))
    )
      fail("Недопустимый или повторный файл обновления.");
    seen.add(p);
    if (
      !Number.isSafeInteger(entry.bytes) ||
      entry.bytes < 0 ||
      entry.bytes > maximumPayloadBytes ||
      !digestPattern.test(entry.sha256 ?? "") ||
      typeof entry.contentBase64 !== "string" ||
      entry.contentBase64.length > Math.ceil(entry.bytes / 3) * 4 + 4
    )
      fail("Некорректный файл обновления.");
    const content = Buffer.from(entry.contentBase64, "base64");
    if (
      content.toString("base64") !== entry.contentBase64 ||
      content.length !== entry.bytes ||
      sha256(content) !== entry.sha256
    )
      fail("Содержимое файла обновления повреждено.");
    return { path: p, bytes: content };
  });
  for (const prefix of [
    "apps/api/dist/",
    "apps/web/dist/",
    "packages/shared/dist/",
    "apps/api/migrations/",
  ])
    if (!files.some((f) => f.path.startsWith(prefix)))
      fail("В пакете отсутствует компонент приложения.");
  for (const p of bundleUpdateFiles)
    if (!seen.has("bundle/" + p)) fail("В пакете отсутствуют файлы обновлятора.");
  return files;
}
async function regularTree(root, prefix = "") {
  const files = [];
  for (const item of await readdir(join(root, prefix), { withFileTypes: true })) {
    const p = prefix ? prefix + "/" + item.name : item.name;
    if (item.isSymbolicLink()) fail("Символические ссылки в файлах установки не поддерживаются.");
    if (item.isDirectory()) files.push(...(await regularTree(root, p)));
    else if (item.isFile()) files.push(safePath(p));
    else fail("Неподдерживаемый тип файла установки.");
  }
  return files.sort();
}
export async function migrationDigest(directory) {
  const files = (await regularTree(directory)).filter((p) => p.endsWith(".js"));
  return {
    count: files.length,
    sha256: sha256(
      canonical(
        await Promise.all(
          files.map(async (p) => [
            p,
            sha256((await readFile(join(directory, p), "utf8")).replaceAll("\r\n", "\n")),
          ]),
        ),
      ),
    ),
  };
}
async function inside(root, path, absent = false) {
  safePath(path);
  const full = resolve(root, path);
  if (!full.startsWith(resolve(root) + "/") && !full.startsWith(resolve(root) + "\\"))
    fail("Путь вышел за пределы установки.");
  let current = resolve(root);
  for (const [i, part] of path.split("/").entries()) {
    current = join(current, part);
    let info;
    try {
      info = await lstat(current);
    } catch (e) {
      if (e.code === "ENOENT" && absent) break;
      throw e;
    }
    if (
      info.isSymbolicLink() ||
      (i < path.split("/").length - 1 ? !info.isDirectory() : !info.isFile())
    )
      fail("Небезопасный путь установки.");
  }
  return full;
}
export async function atomicWrite(root, path, bytes, mode = 0o600) {
  const target = await inside(root, path, true);
  await mkdir(dirname(target), { recursive: true, mode: 0o700 });
  const temporary = target + ".new-" + randomUUID();
  await writeFile(temporary, bytes, { flag: "wx", mode });
  await rename(temporary, target);
}
async function jsonFile(root, name) {
  return JSON.parse(await readFile(await inside(root, name)));
}
async function optionalFile(root, name) {
  try {
    return await readFile(await inside(root, name));
  } catch (e) {
    if (e.code === "ENOENT") return null;
    throw e;
  }
}
async function boundedRead(root, name, maximum) {
  const path = await inside(root, name),
    info = await lstat(path);
  if (info.size > maximum) fail("Файл обновления превышает допустимый размер.");
  return readFile(path);
}
async function transactionId(work) {
  const id = (await boundedRead(work, "transaction-id", 100)).toString().trim();
  if (!/^update\.[a-zA-Z0-9._-]{1,80}$/.test(id)) fail("Некорректный номер попытки обновления.");
  return id;
}
export async function verifyControls(bundle) {
  const text = await readFile(await inside(bundle, "CONTROL-SHA256SUMS"), "utf8"),
    paths = new Set();
  for (const line of text.trim().split(/\r?\n/)) {
    const match = /^([a-f0-9]{64}) {2}(.+)$/.exec(line);
    if (!match) fail("Некорректный список контрольных сумм.");
    const p = safePath(match[2]);
    if (
      paths.has(p) ||
      p === "images.tar" ||
      p.startsWith(".tabula-updates/") ||
      p === "deploy/server/.env" ||
      p.startsWith("deploy/server/.secrets")
    )
      fail("Некорректный состав контрольных файлов.");
    paths.add(p);
    if ((await hashFile(await inside(bundle, p))) !== match[1])
      fail("Файлы установки изменены: " + p + ". Сохраните изменения перед обновлением.");
  }
  for (const p of [
    "BUNDLE-MANIFEST.json",
    "IMAGES.tsv",
    "tabula",
    "deploy/server/compose.distribution.yaml",
    "deploy/server/compose.yaml",
    "deploy/server/compose.public.yaml",
  ])
    if (!paths.has(p)) fail("Комплект не содержит необходимых контрольных файлов.");
  return [...paths].sort();
}
export async function inspectInstallation(
  bundle,
  migrationsDirectory = "/app/apps/api/migrations",
) {
  const controlled = await verifyControls(bundle),
    manifest = await jsonFile(bundle, "BUNDLE-MANIFEST.json");
  if (
    manifest.schemaVersion !== 1 ||
    manifest.platform !== "linux/amd64" ||
    manifest.betaAccess !== "signed-permit-v1" ||
    !revisionPattern.test(manifest.revision ?? "")
  )
    fail("Эта установка не поддерживается обновлятором.");
  validateImages(manifest.images);
  const table = (await readFile(await inside(bundle, "IMAGES.tsv"), "utf8"))
    .trim()
    .split(/\r?\n/)
    .map((line) => line.split("\t"));
  if (table.length !== roles.length) fail("Некорректная таблица образов.");
  for (const image of manifest.images) {
    const entry = table.find((row) => row[0] === image.role);
    if (
      !entry ||
      entry[1] !== image.reference ||
      entry[2] !== image.id ||
      entry[3] !== image.configDigest ||
      !/^sha256:[a-f0-9]{64}$/.test(entry[3])
    )
      fail("Таблица образов не соответствует комплекту.");
  }
  const env = await readFile(await inside(bundle, "deploy/server/.env"), "utf8");
  const read = (key) => {
    const values = env
      .split(/\r?\n/)
      .filter((line) => line.startsWith(key + "="))
      .map((line) => line.slice(key.length + 1));
    if (values.length !== 1) fail("Некорректная конфигурация установки.");
    return values[0];
  };
  const installationId = read("LC_INSTALLATION_ID"),
    project = read("LC_PROJECT");
  if (
    !/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(installationId) ||
    !/^[a-z][a-z0-9-]{2,40}$/.test(project)
  )
    fail("Сохраните исходный ID установки и имя проекта.");
  const site = read("LC_SITE_DNS"),
    httpsPort = read("LC_HTTPS_PORT"),
    bind = read("LC_BIND"),
    rehearsal = read("LC_REHEARSAL");
  if (
    !/^[a-z0-9]+(?:[a-z0-9.-]*[a-z0-9])?$/.test(site) ||
    !/^\d{1,5}$/.test(httpsPort) ||
    +httpsPort < 1 ||
    +httpsPort > 65535 ||
    isIP(bind) !== 4 ||
    !["true", "false"].includes(rehearsal)
  )
    fail("Некорректные адреса действующей установки.");
  const secrets = (await regularTree(join(bundle, "deploy/server/.secrets"))).map(
    (p) => "deploy/server/.secrets/" + p,
  );
  const immutable = await Promise.all(
    controlled.map(async (p) => ({ path: p, sha256: await hashFile(await inside(bundle, p)) })),
  );
  const mutable = await Promise.all(
    ["deploy/server/.env", ...secrets].map(async (p) => ({
      path: p,
      sha256: await hashFile(await inside(bundle, p)),
    })),
  );
  return {
    manifest,
    installationId,
    project,
    immutable,
    mutable,
    site,
    httpsPort,
    bind,
    rehearsal,
    migrations: await migrationDigest(migrationsDirectory),
  };
}
export async function checkCompatibility(bundle, installed, release, publicKey) {
  if (
    installed.migrations.sha256 !== release.compatibility.migrations ||
    installed.migrations.count !== release.compatibility.migrationCount
  )
    fail(
      "Обновление требует другой схемы базы. Используйте инструкцию к полному совместимому комплекту.",
    );
  const receipt = await optionalFile(bundle, ".tabula-updates/current.json");
  if (receipt) {
    const previous = JSON.parse(receipt),
      old = verifyRelease(Buffer.from(JSON.stringify(previous.envelope)), publicKey);
    if (
      old.revision !== installed.manifest.revision ||
      old.sourceCommit !== installed.manifest.sourceCommit ||
      old.compatibility.fingerprint !== release.compatibility.fingerprint
    )
      fail("Версия установки не соответствует подписанной истории обновлений.");
  } else {
    const base = release.compatibility.legacyBases.find(
      (b) =>
        b.revision === installed.manifest.revision &&
        b.sourceCommit === installed.manifest.sourceCommit,
    );
    if (
      !base ||
      !installed.manifest.images.every((image) => base.images[image.role] === image.configDigest)
    )
      fail(
        "Для этой исходной версии нет совместимого малого обновления. Проверьте инструкцию выпуска.",
      );
  }
  return compareRevision(release.revision, installed.manifest.revision);
}
export async function prepareUpdate(bundle, work, publicKey) {
  const installed = await jsonFile(work, "installed.json"),
    envelopeBytes = await boundedRead(work, "release.json", 128 * 1024),
    release = verifyRelease(envelopeBytes, publicKey);
  if ((await checkCompatibility(bundle, installed, release, publicKey)) <= 0)
    fail("Эта версия уже установлена; понижение версии через обновление запрещено.");
  const files = decodePayload(
    await boundedRead(work, "payload.json.gz", maximumPayloadBytes),
    release,
  );
  const migrationFiles = files
    .filter((f) => f.path.startsWith("apps/api/migrations/"))
    .map((f) => [
      f.path.slice("apps/api/migrations/".length),
      sha256(f.bytes.toString().replaceAll("\r\n", "\n")),
    ])
    .sort((a, b) => a[0].localeCompare(b[0]));
  if (
    sha256(canonical(migrationFiles)) !== release.compatibility.migrations ||
    migrationFiles.length !== installed.migrations.count
  )
    fail("Малое обновление не может менять миграции базы.");
  const providedKey = files.find(
    (f) => f.path === "bundle/deploy/server/distribution/update-public-key.pem",
  );
  if (providedKey.bytes.toString().trim() !== publicKey.toString().trim())
    fail("Смена ключа требует отдельного обновлятора.");
  for (const f of files) await atomicWrite(work, "source/" + f.path, f.bytes, 0o644);
  const suffix =
      release.revision +
      "-" +
      installed.installationId.slice(0, 8) +
      "-" +
      randomUUID().slice(0, 8),
    appRef = "tabula-one-beta/update-app:" + suffix,
    edgeRef = "tabula-one-beta/update-edge:" + suffix;
  const index = files.find((f) => f.path === "apps/web/dist/index.html");
  if (!index) fail("В пакете нет главной страницы приложения.");
  const plan = {
    release,
    envelope: JSON.parse(envelopeBytes),
    appRef,
    edgeRef,
    indexSha256: sha256(index.bytes),
    baseApp: installed.manifest.images.find((i) => i.role === "app").reference,
    baseEdge: installed.manifest.images.find((i) => i.role === "public-edge").reference,
  };
  await atomicWrite(work, "plan.json", JSON.stringify(plan, null, 2) + "\n");
  await atomicWrite(
    work,
    "plan.env",
    Object.entries({
      APP_REF: appRef,
      EDGE_REF: edgeRef,
      BASE_APP: plan.baseApp,
      BASE_EDGE: plan.baseEdge,
      NEW_REVISION: release.revision,
      SITE_DNS: installed.site,
      HTTPS_PORT: installed.httpsPort,
      SITE_BIND: installed.bind,
      REHEARSAL: installed.rehearsal,
    })
      .map(([k, v]) => k + "\t" + v)
      .join("\n") + "\n",
  );
  return plan;
}
export async function assertUnchanged(bundle, installed) {
  for (const f of [...installed.immutable, ...installed.mutable])
    if ((await hashFile(await inside(bundle, f.path))) !== f.sha256)
      fail("Установка изменилась во время подготовки. Повторите проверку.");
}
export async function stageControls(bundle, work) {
  const installed = await jsonFile(work, "installed.json"),
    plan = await jsonFile(work, "plan.json"),
    inspected = await jsonFile(work, "new-images.json");
  await assertUnchanged(bundle, installed);
  const images = installed.manifest.images.map((image) => {
    if (!["app", "public-edge"].includes(image.role)) return image;
    const reference = image.role === "app" ? plan.appRef : plan.edgeRef,
      actual = inspected.find((i) => i.RepoTags?.includes(reference));
    if (
      !actual ||
      actual.Os !== "linux" ||
      actual.Architecture !== "amd64" ||
      !/^sha256:[a-f0-9]{64}$/.test(actual.Id) ||
      actual.Config?.Labels?.["uz.tabulaone.update"] !== plan.release.revision ||
      actual.Config?.Labels?.["uz.tabulaone.installation"] !== installed.installationId
    )
      fail("Новый образ не прошёл проверку.");
    return { ...image, reference, id: actual.Id, configDigest: actual.Id };
  });
  validateImages(images);
  const stage = join(work, "stage");
  await mkdir(stage, { recursive: true, mode: 0o700 });
  const all = new Map();
  for (const f of installed.immutable)
    if (f.path !== "BUNDLE-MANIFEST.json")
      all.set(f.path, await readFile(await inside(bundle, f.path)));
  for (const p of bundleUpdateFiles) all.set(p, await readFile(join(work, "source/bundle", p)));
  let wrapper = all.get("tabula").toString();
  if (wrapper.split("@@APP_IMAGE@@").length !== 2) fail("Некорректный шаблон команд установки.");
  all.set("tabula", Buffer.from(wrapper.replace("@@APP_IMAGE@@", plan.appRef)));
  all.set(
    "IMAGES.tsv",
    Buffer.from(
      images.map((i) => [i.role, i.reference, i.id, i.configDigest].join("\t")).join("\n") + "\n",
    ),
  );
  all.set("deploy/server/compose.distribution.yaml", Buffer.from(distributionOverlay(images)));
  const files = [...all]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([p, b]) => ({ path: p, bytes: b.length, sha256: sha256(b) }));
  const manifest = {
    ...installed.manifest,
    revision: plan.release.revision,
    sourceCommit: plan.release.sourceCommit,
    sourceRelease: plan.release.sourceRelease,
    imageTransport: "signed-application-update",
    images,
    files,
    sourceChangesSha256: sha256(all.get("SOURCE-CHANGES.json")),
    updateProtocol,
  };
  all.set("BUNDLE-MANIFEST.json", Buffer.from(JSON.stringify(manifest, null, 2) + "\n"));
  all.set(
    "CONTROL-SHA256SUMS",
    Buffer.from(
      [...all]
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([p, b]) => sha256(b) + "  " + p)
        .join("\n") + "\n",
    ),
  );
  all.set(
    "SHA256SUMS",
    Buffer.from(
      [...all]
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([p, b]) => sha256(b) + "  " + p)
        .join("\n") + "\n",
    ),
  );
  all.set(
    ".tabula-updates/current.json",
    Buffer.from(
      JSON.stringify({ transaction: await transactionId(work), envelope: plan.envelope }, null, 2) +
        "\n",
    ),
  );
  const paths = [];
  for (const [p, b] of all) {
    const old = await optionalFile(bundle, p);
    if (old !== null && sha256(old) === sha256(b)) continue;
    paths.push(p);
    await atomicWrite(stage, p, b, p === "tabula" || p.endsWith("/update.sh") ? 0o755 : 0o644);
  }
  paths.sort();
  await atomicWrite(work, "paths.json", JSON.stringify(paths));
  return paths;
}
export async function backupControls(bundle, work) {
  const installed = await jsonFile(work, "installed.json");
  await assertUnchanged(bundle, installed);
  const paths = await jsonFile(work, "paths.json"),
    before = [];
  for (const p of paths) {
    const bytes = await optionalFile(bundle, p);
    const mode = bytes === null ? null : (await lstat(await inside(bundle, p))).mode & 0o777;
    before.push({
      path: p,
      exists: bytes !== null,
      sha256: bytes === null ? null : sha256(bytes),
      mode,
    });
    if (bytes !== null) await atomicWrite(work, "backup/files/" + p, bytes, 0o600);
  }
  for (const f of installed.mutable)
    await atomicWrite(
      work,
      "backup/config/" + f.path,
      await readFile(await inside(bundle, f.path)),
      0o600,
    );
  await atomicWrite(work, "backup/paths.json", JSON.stringify(before, null, 2));
}
export async function applyControls(bundle, work) {
  await assertUnchanged(bundle, await jsonFile(work, "installed.json"));
  const before = await jsonFile(work, "backup/paths.json");
  for (const f of before) {
    const current = await optionalFile(bundle, f.path);
    if ((current === null ? null : sha256(current)) !== f.sha256)
      fail("Файлы установки изменились перед применением.");
  }
  for (const p of await jsonFile(work, "paths.json"))
    await atomicWrite(
      bundle,
      p,
      await readFile(await inside(join(work, "stage"), p)),
      before.find((f) => f.path === p)?.mode ??
        (p === "tabula" || p.endsWith("/update.sh")
          ? 0o755
          : p.startsWith(".tabula-updates/")
            ? 0o600
            : 0o644),
    );
  await verifyControls(bundle);
}
export async function checkRestore(bundle, work) {
  const before = await jsonFile(work, "backup/paths.json");
  for (const f of before) {
    const current = await optionalFile(bundle, f.path),
      staged = await boundedRead(join(work, "stage"), f.path, maximumPayloadBytes);
    const digest = current === null ? null : sha256(current);
    if (digest !== f.sha256 && digest !== sha256(staged))
      fail("Файлы изменены после попытки обновления. Сохраните изменения перед восстановлением.");
    if (f.exists && (await hashFile(await inside(join(work, "backup/files"), f.path))) !== f.sha256)
      fail("Резервная копия файлов повреждена.");
  }
  return before;
}
export async function restoreControls(bundle, work) {
  for (const f of await checkRestore(bundle, work)) {
    if (f.exists) {
      const bytes = await readFile(await inside(join(work, "backup/files"), f.path));
      if (sha256(bytes) !== f.sha256) fail("Резервная копия файлов повреждена.");
      await atomicWrite(bundle, f.path, bytes, f.mode);
    } else {
      const file = await inside(bundle, f.path, true);
      try {
        await unlink(file);
      } catch (e) {
        if (e.code !== "ENOENT") throw e;
      }
    }
  }
  await verifyControls(bundle);
}
export async function downloadArtifact(url, maximum, expectedBytes, fetcher = fetch) {
  const signal = AbortSignal.timeout(180000);
  let response;
  for (let redirects = 0; redirects < 6; redirects++) {
    const parsed = new URL(url);
    if (
      parsed.protocol !== "https:" ||
      ![
        "raw.githubusercontent.com",
        "github.com",
        "release-assets.githubusercontent.com",
        "objects.githubusercontent.com",
      ].includes(parsed.hostname) ||
      parsed.username ||
      parsed.password
    )
      fail("Недопустимый адрес загрузки обновления.");
    response = await fetcher(url, {
      redirect: "manual",
      signal,
      headers: { "Cache-Control": "no-cache", "User-Agent": "Tabula-One-server-updater/1" },
    });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const next = response.headers.get("location");
      await response.body?.cancel();
      if (!next) fail("Некорректное перенаправление загрузки.");
      url = new URL(next, url).href;
      continue;
    }
    if (response.status !== 200) fail("Сервер обновлений недоступен. Повторите попытку позже.");
    const announced = Number(response.headers.get("content-length"));
    if (Number.isFinite(announced) && announced > maximum) fail("Пакет обновления слишком велик.");
    const chunks = [];
    let size = 0;
    for await (const part of response.body) {
      size += part.length;
      if (size > maximum) fail("Загрузка превышает допустимый размер.");
      chunks.push(Buffer.from(part));
    }
    if (expectedBytes !== undefined && size !== expectedBytes)
      fail("Пакет обновления скачан не полностью.");
    return Buffer.concat(chunks);
  }
  fail("Слишком много перенаправлений обновления.");
}
export function validateRuntime(state, installed, before) {
  if (
    !state ||
    state.migrations !== installed.migrations.count ||
    state.installationId !== installed.installationId ||
    state.betaRequired !== true ||
    !digestPattern.test(state.configHash ?? "")
  )
    fail("Параметры действующего приложения не соответствуют установке.");
  if (before && (state.configHash !== before.configHash || state.permitHash !== before.permitHash))
    fail("Настройки или разрешение изменились во время обновления.");
  if (
    ![state.lessons, state.recordings, state.participants].every(
      (n) => Number.isSafeInteger(n) && n >= 0,
    )
  )
    fail("Не удалось проверить активные уроки.");
  return state;
}
export async function probeHttps(installed, expectedIndex, ca) {
  if (!digestPattern.test(expectedIndex)) fail("Отсутствует контрольная сумма страницы.");
  for (const path of ["/ready", "/teacher"]) {
    const result = await new Promise((resolve, reject) => {
      const req = httpsRequest(
        {
          hostname: "127.0.0.1",
          port: 9443,
          servername: installed.site,
          headers: { Host: installed.site },
          path,
          rejectUnauthorized: true,
          ...(ca ? { ca } : {}),
        },
        (res) => {
          const chunks = [];
          let size = 0;
          res.on("data", (b) => {
            size += b.length;
            if (size > 4 * 1024 * 1024) req.destroy(new Error("Слишком большой ответ сервера."));
            else chunks.push(b);
          });
          res.on("end", () => resolve({ status: res.statusCode, bytes: Buffer.concat(chunks) }));
          res.on("error", reject);
        },
      );
      req.setTimeout(10000, () =>
        req.destroy(new Error("Проверка сайта превысила время ожидания.")),
      );
      req.on("error", reject);
      req.end();
    });
    if (result.status !== 200 || (path === "/teacher" && sha256(result.bytes) !== expectedIndex))
      fail("Обновлённый сайт не прошёл проверку HTTPS.");
  }
}
export function validateCompose(before, after, plan) {
  const a = structuredClone(before),
    b = structuredClone(after);
  for (const service of ["setup", "api", "cleanup", "edge"]) {
    if (!a.services?.[service] || !b.services?.[service])
      fail("В конфигурации отсутствует обязательный сервис.");
  }
  for (const service of ["setup", "api", "cleanup", "master", "teacher", "edge"]) {
    if (!a.services?.[service] && !b.services?.[service]) continue;
    if (
      !a.services?.[service] ||
      !b.services?.[service] ||
      b.services[service].image !== (service === "edge" ? plan.edgeRef : plan.appRef)
    )
      fail("Неожиданный образ в конфигурации обновления.");
    delete a.services[service].image;
    delete b.services[service].image;
  }
  if (canonical(a) !== canonical(b))
    fail("Обновление меняет параметры запуска. Установка отменена.");
}
async function cli() {
  const [command, bundle, work, ...args] = process.argv.slice(2);
  if (!bundle || !work) fail("Не указана папка установки.");
  const publicKey = await readFile(keyFile);
  if (command === "download-feed")
    await atomicWrite(
      work,
      "release.json",
      await downloadArtifact(updateFeed + "?t=" + Date.now(), 128 * 1024),
    );
  else if (command === "download-payload") {
    const release = verifyRelease(await boundedRead(work, "release.json", 128 * 1024), publicKey);
    await atomicWrite(
      work,
      "payload.json.gz",
      await downloadArtifact(release.payload.url, release.payload.bytes, release.payload.bytes),
    );
  } else if (command === "inspect") {
    await atomicWrite(
      work,
      "installed.json",
      JSON.stringify(await inspectInstallation(bundle), null, 2),
    );
  } else if (command === "release") {
    const bytes = await boundedRead(work, "release.json", 128 * 1024),
      release = verifyRelease(bytes, publicKey),
      installed = await jsonFile(work, "installed.json"),
      comparison = await checkCompatibility(bundle, installed, release, publicKey);
    await atomicWrite(
      work,
      "download.env",
      `PAYLOAD_URL\t${release.payload.url}\nPAYLOAD_BYTES\t${release.payload.bytes}\nUPDATE_AVAILABLE\t${comparison > 0 ? 1 : 0}\nNEW_REVISION\t${release.revision}\n`,
    );
    console.log(
      `Установлено: ${installed.manifest.revision}\nДоступно: ${release.revision}\n${comparison > 0 ? "Обновление доступно." : "Новая версия не требуется."}\n${release.notes}`,
    );
  } else if (command === "prepare") await prepareUpdate(bundle, work, publicKey);
  else if (command === "stage") await stageControls(bundle, work);
  else if (command === "backup") await backupControls(bundle, work);
  else if (command === "apply") await applyControls(bundle, work);
  else if (command === "restore") await restoreControls(bundle, work);
  else if (command === "restore-check") await checkRestore(bundle, work);
  else if (command === "unchanged")
    await assertUnchanged(bundle, await jsonFile(work, "installed.json"));
  else if (command === "gate") {
    if (!/^[a-z-]+\.json$/.test(args[0] ?? "")) fail("Некорректная проверка состояния.");
    const state = validateRuntime(
      await jsonFile(work, args[0]),
      await jsonFile(work, "installed.json"),
      args[1] === "same" ? await jsonFile(work, "runtime-before.json") : undefined,
    );
    if (state.lessons || state.recordings || state.participants)
      fail("Сначала завершите активные уроки и записи. Обновление не установлено.");
    if (args[1] === "space") {
      if (!Number.isSafeInteger(state.databaseBytes) || state.databaseBytes < 0)
        fail("Не удалось оценить размер резервной копии.");
      const fs = await statfs(bundle),
        plan = await jsonFile(work, "plan.json");
      if (
        fs.bavail * fs.bsize <
        2 * 1024 * 1024 * 1024 + state.databaseBytes * 2 + plan.release.payload.unpackedBytes * 2
      )
        fail("Недостаточно места для резервной копии базы и обновления.");
    }
  } else if (command === "probe") {
    const installed = await jsonFile(work, "installed.json"),
      ca =
        installed.rehearsal === "true" ? await readFile(join(work, "rehearsal-ca.pem")) : undefined;
    const expected =
      args[0] === "old"
        ? (await readFile(join(work, "old-web-index.sha"), "utf8")).trim()
        : (await jsonFile(work, "plan.json")).indexSha256;
    await probeHttps(installed, expected, ca);
  } else if (command === "compose")
    validateCompose(
      await jsonFile(work, "compose-before.json"),
      await jsonFile(work, "compose-after.json"),
      await jsonFile(work, "plan.json"),
    );
  else if (command === "phase") {
    if (!/^[a-z-]+$/.test(args[0] ?? "")) fail("Некорректное состояние обновления.");
    const state = {
      phase: args[0],
      transaction: await transactionId(work),
      time: new Date().toISOString(),
    };
    await atomicWrite(work, "transaction.json", JSON.stringify(state, null, 2));
    if (args[0] !== "prepared") {
      await atomicWrite(bundle, ".tabula-updates/last.json", JSON.stringify(state, null, 2));
      await atomicWrite(
        bundle,
        ".tabula-updates/LAST",
        state.transaction + "\t" + state.phase + "\n",
      );
    }
  } else fail("Неизвестная команда обновлятора.");
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url))
  cli().catch((e) => {
    console.error(e.message);
    process.exitCode = 1;
  });
